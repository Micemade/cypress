<?php
/*
Plugin Name: Aligator Shortcodes
Plugin URI: http://aligator-studio.com
Description: Shortcodes plugin for Aligator Studio WP themes
Version: 1.0.0
Author: Aligator Studio
Author URI: http://aligator-studio.com
*/

/*
*	SETTINGS
*
*/


// load viewport meta in head


function assp_viewport (){

	echo '<meta name="viewport" content=" width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1" />';
}

add_action( 'wp_head', 'assp_viewport' );



// add admin css and scripts


function assp_admin_includes() {
    
    wp_register_style( 'assp-popup-editor-css', plugins_url('/css/popup.css',__FILE__),'','','all' );
    wp_register_style( 'assp-colorpicker-css', plugins_url('/css/colorpicker.css',__FILE__),'','','all' );

    wp_enqueue_style( 'assp-popup-editor-css' );
    wp_enqueue_style( 'assp-colorpicker-css' );

    wp_register_script( 'assp-colorpicker-js', plugins_url('/js/colorpicker.js',__FILE__),array(),'','true' );
    wp_register_script( 'assp-popup-functions-js', plugins_url('/js/popup-functions.js',__FILE__),array(),'','true' );    

    wp_enqueue_script( 'assp-colorpicker-js' );
    wp_enqueue_script( 'assp-popup-functions-js' );

}
add_action( 'admin_enqueue_scripts', 'assp_admin_includes' );



// load frontend css and scripts


function assp_css() {
	wp_register_style('aligator-shortcodes-css', plugins_url('/css/aligator-shortcodes.css',__FILE__),'','','all');
	wp_register_style('assp-grid-tablet-css', plugins_url('/css/grid-tablet.css',__FILE__),'','','all');

	wp_enqueue_style('aligator-shortcodes-css');
	wp_enqueue_style('assp-grid-tablet-css');


	wp_register_script('assp-waypoints-js', plugins_url('/js/waypoints.min.js',__FILE__),array(),'','false');
    wp_register_script('assp-aligator-shortcodes-js', plugins_url('/js/aligator-shortcodes.js',__FILE__),array(),'','false');  

	wp_enqueue_script( 'assp-waypoints-js' );
    wp_enqueue_script( 'assp-aligator-shortcodes-js' );
    wp_enqueue_script( 'jquery' );

}
add_action('wp_enqueue_scripts', 'assp_css');



// load translations
  

function assp_action_init() {  
    load_plugin_textdomain('aligator-shortcodes', false, dirname(plugin_basename(__FILE__)) . '/languages');  
}  
add_action('init', 'assp_action_init');  



// load editor button


function assp_shortcodes_media_button( $button ) {
	global $pagenow, $wp_version;
	$output = '';
	if ( in_array( $pagenow, array( 'post.php', 'page.php', 'post-new.php', 'post-edit.php','themes.php' ) ) ) {

		if ( version_compare( $wp_version, '3.5', '<' ) ) {
			$img 	= '<img src="' .  plugins_url( '/images/shortcodes-button.png', __FILE__ ) . '" width="16px" height="16px" alt="' . esc_attr__( 'Add  shortcodes', 'aligator-shortcodes' )  . '" />';
			$output = '<a href="#TB_inline?width=670&inlineId=aligator-shortcodes" class="thickbox" title="' . esc_attr__( 'Add Shortcodes', 'aligator-shortcodes' )  . '">' . $img . '</a>';
		} else {
			$img 	= '<span class="wp-media-buttons-icon" style="background-image: url(' .   plugins_url( '/images/shortcodes-button.png', __FILE__ ) . '); margin-top: -1px;"></span>';
			$output = '<a href="#TB_inline?width=670&inlineId=aligator-shortcodes" class="thickbox button" title="' . esc_attr__( 'Add shortcodes', 'aligator-shortcodes' ) . '" style="padding-left: .4em;">' . $img . ' ' . esc_attr__( 'Add Shortcodes', 'aligator-shortcodes' ) . '</a>';
		}
	}
	return $button . $output;
}
add_filter('media_buttons_context', 'assp_shortcodes_media_button' );



// editor button popup window


function assp_inline_popup_content() {
	global $pagenow;
	//if ( $pagenow != 'themes.php' ) {
	?>
		<div id="aligator-shortcodes" style="display:none;">
		  <?php include('popup.php')?>
		</div>
	<?php
	//}
}
add_action( 'admin_footer',  'assp_inline_popup_content' );



/*
*Shortcode: Google maps
*
*/


function assp_google_map( $atts ) {

	$atts = shortcode_atts(
		array(
			'address' 	=> false,
			'width' 	=> '100%',
			'height' 	=> '400px'
		),
		$atts
	);

	$address = $atts['address'];

	if( $address ) :

		wp_print_scripts( 'google-maps-api' );

		$coordinates = google_map_get_coordinates( $address );

		if( !is_array( $coordinates ) )
			return;

		$map_id = uniqid( 'google_map_' ); // generate a unique ID for this map

		ob_start(); ?>
		<div class="google_map_canvas" id="<?php echo esc_attr( $map_id ); ?>" style="height: <?php echo esc_attr( $atts['height'] ); ?>; width: <?php echo esc_attr( $atts['width'] ); ?>"></div>
	    <script type="text/javascript">
			var map_<?php echo $map_id; ?>;
			function pw_run_map_<?php echo $map_id ; ?>(){
				var location = new google.maps.LatLng("<?php echo $coordinates['lat']; ?>", "<?php echo $coordinates['lng']; ?>");
				var map_options = {
					zoom: 15,
					center: location,
					mapTypeId: google.maps.MapTypeId.ROADMAP
				}
				map_<?php echo $map_id ; ?> = new google.maps.Map(document.getElementById("<?php echo $map_id ; ?>"), map_options);
				var marker = new google.maps.Marker({
				position: location,
				map: map_<?php echo $map_id ; ?>
				});
			}
			pw_run_map_<?php echo $map_id ; ?>();
		</script>
		<?php
	endif;
	return ob_get_clean();
}
add_shortcode( 'google_map', 'assp_google_map' );



/**
 * Loads Google Map API
 *
 * @access      private
 * @since       1.0
 * @return      void
*/


function google_map_load_scripts() {
	wp_register_script( 'google-maps-api', 'http://maps.google.com/maps/api/js?sensor=false' );
}
add_action( 'wp_enqueue_scripts', 'google_map_load_scripts' );



/**
 * Retrieve coordinates for an address
 *
 * Coordinates are cached using transients and a hash of the address
 *
*/


function google_map_get_coordinates( $address, $force_refresh = false ) {

    $address_hash = md5( $address );

    $coordinates = get_transient( $address_hash );

    if ($force_refresh || $coordinates === false) {

    	$args       = array( 'address' => urlencode( $address ), 'sensor' => 'false' );
    	$url        = add_query_arg( $args, 'http://maps.googleapis.com/maps/api/geocode/json' );
     	$response 	= wp_remote_get( $url );

     	if( is_wp_error( $response ) )
     		return;

     	$data = wp_remote_retrieve_body( $response );

     	if( is_wp_error( $data ) )
     		return;

		if ( $response['response']['code'] == 200 ) {

			$data = json_decode( $data );

			if ( $data->status === 'OK' ) {

			  	$coordinates = $data->results[0]->geometry->location;

			  	$cache_value['lat'] 	= $coordinates->lat;
			  	$cache_value['lng'] 	= $coordinates->lng;
			  	$cache_value['address'] = (string) $data->results[0]->formatted_address;

			  	// cache coordinates for 3 months
			  	set_transient($address_hash, $cache_value, 3600*24*30*3);
			  	$data = $cache_value;

			} elseif ( $data->status === 'ZERO_RESULTS' ) {
			  	return __( 'No location found for the entered address.', 'pw-maps' );
			} elseif( $data->status === 'INVALID_REQUEST' ) {
			   	return __( 'Invalid request. Did you enter an address?', 'pw-maps' );
			} else {
				return __( 'Something went wrong while retrieving your map, please ensure you have entered the short code correctly.', 'pw-maps' );
			}

		} else {
		 	return __( 'Unable to contact Google API service.', 'pw-maps' );
		}

    } else {
       // return cached results
       $data = $coordinates;
    }

    return $data;
}



/*
*Shortcode: Video
*
*/

// Info: [video id="23KHLW2dw_o"] option site= youtube, screenr,vimeo,dailymotion,yahoo,bliptv,veoh,viddler w=100% h=100%


function assp_video( $atts, $content=null ) {
	extract(
		shortcode_atts(array(
			'site' => 'youtube',
			'id' => '',
			'w' => '100%',
			'h' => '370px'
		), $atts)
	);
	if ( $site == "youtube" ) { $src = 'http://www.youtube-nocookie.com/embed/'.$id; }
	else if ( $site == "screenr" ) { $src = 'http://www.screenr.com/embed/'.$id; }
	else if ( $site == "vimeo" ) { $src = 'http://player.vimeo.com/video/'.$id; }
	else if ( $site == "dailymotion" ) { $src = 'http://www.dailymotion.com/embed/video/'.$id; }
	else if ( $site == "yahoo" ) { $src = 'http://d.yimg.com/nl/vyc/site/player.html#vid='.$id; }
	else if ( $site == "bliptv" ) { $src = 'http://a.blip.tv/scripts/shoggplayer.html#file=http://blip.tv/rss/flash/'.$id; }
	else if ( $site == "veoh" ) { $src = 'http://www.veoh.com/static/swf/veoh/SPL.swf?videoAutoPlay=0&permalinkId='.$id; }
	else if ( $site == "viddler" ) { $src = 'http://www.viddler.com/simple/'.$id; }
	if ( $id != '' ) {
		return '<iframe style="width:'.$w.'; height:'.$h.';" src="'.$src.'" class="vid iframe-'.$site.'"></iframe>';
	}
}
add_shortcode('video','assp_video');



/*
*	Buttons
*
*/
// Info: [button text="Submit" title="Submit Button" url="http://www.aligator-studio.com/" size="small" bg_color="#000" text_color="#FFF"  target="_blank"]
// Options: Size: small, large (default:medium) Shape: rounded, pill (default:square) Target: _blank (default:_self)


function assp_button( $atts, $content = null ) {
    extract(shortcode_atts(array(
	    'text' => 'Submit',
	    'title' => '',
	    'size' => '',
	    'shape' => '',
	    'bg_color' => '#000',
	    'text_color' => '#FFF',
		'text_shadow' => '#000',
	    'url' => '#',	    
	    'target' => '',
    ), $atts));
    $target = ($target == '_blank') ? ' target="_blank"' : '';
    $btn_txt = $content ? do_shortcode($content) : do_shortcode($text); 
    $html = '
                <a class="assp-button '.$size.' '.$shape.'" href="'.$url.'" title="'.$title.'"'.$target.' style="background-color:'.$bg_color.'; color:'.$text_color.'; text-shadow:1px 1px 0 '.$text_shadow.'">'.$btn_txt.'</a>
	     ';
    return $html;
}
add_shortcode('button', 'assp_button');



/**
 *	Shortcode: Columns
 *
 */

// Column: box 
// Info: [box]-- Enter your columns here --[/box]


function assp_grid_box( $atts, $content = null ) {

    return '<div class="grid-parent">'.do_shortcode($content).'</div>';
}
add_shortcode('box', 'assp_grid_box');



// Column: one_half 
// Info: [one_half]-- Enter your content here --[/one_half], option tablet or mobile = 100, 50 


function assp_one_half( $atts, $content = null ) {
	extract(shortcode_atts(array(
	    'tablet' => '50',
	    'mobile' => '50'
    ), $atts));
	return '<div class="grid-50 tablet-grid-'.$tablet.' mobile-grid-'.$mobile.'">'.do_shortcode($content).'</div>';
}
add_shortcode('one_half', 'assp_one_half');



//Column: one_third
// Info: [one_third]-- Enter your content here --[/one_third], option tablet or mobile = 100, 50


function assp_one_third( $atts, $content = null ) {
	extract(shortcode_atts(array(
	    'tablet' => '33',
	    'mobile' => '33'
    ), $atts));
	return '<div class="grid-33 tablet-grid-'.$tablet.' mobile-grid-'.$mobile.'">'.do_shortcode($content).'</div>';
}
add_shortcode('one_third', 'assp_one_third');



// Column: two_third
// Info: [two_third]-- Enter your content here --[/two_third], option tablet or mobile = 100, 50


function assp_two_third( $atts, $content = null ) {
	extract(shortcode_atts(array(
	    'tablet' => '66',
	    'mobile' => '66'
    ), $atts));
	return '<div class="grid-66 tablet-grid-'.$tablet.' mobile-grid-'.$mobile.'">'.do_shortcode($content).'</div>';
}
add_shortcode('two_third', 'assp_two_third');



// Column: one_fourth
// Info: [one_fourth]-- Enter your content here --[/one_fourth], option tablet or mobile = 100, 50


function assp_one_fourth( $atts, $content = null ) {
	extract(shortcode_atts(array(
	    'tablet' => '25',
	    'mobile' => '25'
    ), $atts));
	return '<div class="grid-25 tablet-grid-'.$tablet.' mobile-grid-'.$mobile.'">'.do_shortcode($content).'</div>';
}
add_shortcode('one_fourth', 'assp_one_fourth');



// Column: three_fourth
// Info: [three_fourth]-- Enter your content here --[/three_fourth], option tablet or mobile = 100, 50
function assp_three_fourth( $atts, $content = null ) {
	extract(shortcode_atts(array(
	    'tablet' => '75',
	    'mobile' => '75'
    ), $atts));
	return '<div class="grid-75 tablet-grid-'.$tablet.' mobile-grid-'.$mobile.'">'.do_shortcode($content).'</div>';
}
add_shortcode('three_fourth', 'assp_three_fourth');



/*
*Shortcode: Animated bars
*
*/



// Usage: [bars][bar title="php" width="70" color="#ff0000" /] [bar title="css" width="80" color="#ff0000" /] [/bars]


function assp_bar_item( $atts, $content = null ) {
    extract(shortcode_atts(array(
		'barstitle'  => '',
	    'title'      => '',
	    'width'      => '',
	    'color'      => ''
    ), $atts));
    global $single_bar_array;
    $single_bar_array[] = array('barstitle' => $barstitle,'title' => $title,'width' => $width,'color' => $color, );
    //return $single_bar_array;
}
add_shortcode('bar', 'assp_bar_item');



function assp_bars_function( $atts, $content = null ) {
   extract(shortcode_atts(array(
		'barstitle'  => ''
    ), $atts));
   
   
   global $single_bar_array;
    $single_bar_array = array(); // clear the array

    $bar = '<div class="clearfix"></div>';
    
    do_shortcode($content);	// execute the '[bar]' shortcode first to get the title and content
	
	$bars_output = '<div class="bars">';

	$barstitle ? $bars_output .= '<h3>' .$barstitle .'</h3>' : '';
	
	foreach ( $single_bar_array as $barkey => $bar_content_array ) {
	
		$bars_output .= '<p>' . $bar_content_array['title'] . '</p>' ;
		$bars_output .= '<div class="barholder" data-perc="'.$bar_content_array['width'].'" title="'.$bar_content_array['title'].'">';
		
		$bars_output .= '<div class="bar" style="background-color:'.$bar_content_array['color'].'"><span class="perc"></span></div>';
		
		$bars_output .= '</div>';
    }

	$bars_output .= '</div><div class="clearfix"></div>';
    return $bar . $bars_output;
}
add_shortcode('bars', 'assp_bars_function');


/*
*Shortcode: Pricetables
*
*/


// Usage: [pricetable title="Title" subtitle="subtitle" link="link" link_text="link text" bg_color="#000333" text_color="#000333" featured=true/false]-- Enter your content here --[/pricetable]
function assp_pricetable( $atts, $content = null ) {
    extract(shortcode_atts(array(
	    'title'         => 'Price title',
	    'subtitle'      => 'explanation',
		'link'          => 'http://themeforest.com',
	    'link_text'     => 'Go',
	    'width'         => 'third',
	    'bg_color'      => '#666',
	    'text_color'    => '#ccc',
	    'text_shadow'   => '#333',
	    'featured'      => false
    ), $atts));
	
	if ( $width == 'half' ) {
		$wdth = 'grid-50';
	}elseif ( $width == 'third' ) {
		$wdth = 'grid-33';
	}elseif ( $width == 'fourth' ) {
		$wdth = 'grid-25';
	}elseif ( $width == 'fifth' ) {
		$wdth = 'grid-20';
	};
	
	
	$featured = ($featured == 'true') ? ' featured' : '';
		
	$pricet_output .= '<div class="pricetable '. $wdth. ''. $featured. '" >';
	$pricet_output .= '<div style="border: 1px solid '.$bg_color.'; background-color:'.$bg_color.'; color:'.$text_color.'; text-shadow:1px 1px 0 '.$text_shadow.'">';
	$pricet_output .= '<h4>' .$title. '</h4>';
	$pricet_output .= '<h5>' .$subtitle. '</h5>';
    $pricet_output .= '<div class="content">';
    $pricet_output .= do_shortcode($content);
    $pricet_output .= '</div>';
    $pricet_output .= '<div class="footer'.$featured.'">';	
    $pricet_output .= '<a class="assp-button rounded" style="color:'.$text_color.'; text-shadow:1px 1px 0 '.$text_shadow.'" href="'.$link.'" title="'.$title.'" >'.$link_text.'</a>';    
	$pricet_output .= '</div> </div> </div>';

	
    return $pricet_output;
}
add_shortcode('pricetable', 'assp_pricetable');


/*
*Shortcode: List Styles
*
*/


// Usage: [list_style style="arrow"]-- Enter your list here --[/list_style]
function assp_list_style( $atts, $content = null ) {
    extract(shortcode_atts(array(
	    'style'      => '',
    ), $atts));
	
    $toggle_output = '<div class="liststyler '. $style .'">';
    $toggle_output .= do_shortcode($content);
	$toggle_output .= '</div><!-- end style -->';
    return $toggle_output;
}
add_shortcode('list_style', 'assp_list_style');



/*
*Shortcode: InsertQuote 
*
*/
// Info: [insertquote style="left" author"Ana" width="70%"]-- Enter your content here --[/insertquote]  style options: 'left', 'right' , 'center'


function assp_insertquote( $atts, $content = null ) {
    extract(shortcode_atts(array(
	    'style' => 'left',
		'author' => '',
		'width' => ''
    ), $atts));
   
	if( $style == 'right') {
		$align = 'rightalign';
	}elseif ( $style == 'left' ) {
		$align = 'leftalign';
	}elseif ( $style == 'center' ) {
		$align = 'centeralign';
	}
    
	$html = '<blockquote class="'.$align.'" '. ($width ? 'style="width:'.$width.';"' : '') .'>';
	$html .= do_shortcode($content);
	$html .= '<div class="author">'.$author.'</div>';
	$html .= '</blockquote>';
	return $html;
}
add_shortcode('insertquote', 'assp_insertquote');



/*
*	Shortcode: Horizontal line
*
*/
// Info: [horizontal_line]


function assp_horiz_line( $atts, $content = null ) {
    return '<hr>';
}
add_shortcode('horizontal_line', 'assp_horiz_line');




/*
*	Shortcode: Dropcap 
*
*/
// Info: [dropcap style="dc_light"]A[/dropcap], style options: 'light', 'dark'


function assp_dropcap( $atts, $content = null ) {
    extract(shortcode_atts(array(
	    'style' => 'light'		
    ), $atts));
	$bcolour = ($style == 'dark') ? 'dark' : 'light';
    return '<span class="dropcap '.$bcolour.'">'.$content.'</span>';
}
add_shortcode('dropcap', 'assp_dropcap');



/*
*	Shortcode: Clear float
*
*/
// Info: [clear_float]


function assp_clear_float( $atts, $content = null ) {
    return '<div class="clear"></div>';
}
add_shortcode('clear_float', 'assp_clear_float');