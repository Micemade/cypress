<?php
// this file contains the contents of the popup window

?>

<script type="text/javascript">

function insertGmap() {

	var address = jQuery('#gmap-dialog input#gmap-address').val();
	var width = jQuery('#gmap-dialog input#gmap-width').val();
	var unit = jQuery('#gmap-dialog select#gmap-wunit').val();
	var height = jQuery('#gmap-dialog input#gmap-height').val();			 
	 
	var output = '';
	output = '[google_map ';
	output += 'address="' + address + '" ';
	output += 'width="' + width + unit +'" ';
	output += 'height="' + height + 'px" ';
	output += ']';

	/** Send shortcode to editor */
	window.send_to_editor( output );
}

function insertVideo() {

	var site = jQuery('#video-dialog select#video-src').val();
	var id = jQuery('#video-dialog input#video-id').val();
	var w = jQuery('#video-dialog input#video-width').val();
	var wunit = jQuery('#video-dialog select#video-wunit').val();
	var h = jQuery('#video-dialog input#video-height').val();
	var hunit = jQuery('#video-dialog select#video-hunit').val();		 
	 
	var output = '';
	
	// setup the output of shortcode
	output = '[video  ';
	output += 'site="' + site + '" ';
	output += 'id="' + id + '" ';
	output += 'w="' + w + wunit +'" ';
	output += 'h="' + h + hunit +'" ';
	output += ']';

	/** Send shortcode to editor */
	window.send_to_editor( output );
}

function insertButton() {

	var selectedText = tinymce.activeEditor.selection.getContent();
	
	var url = jQuery('#button-dialog input#button-url').val();
	var target = jQuery('#button-dialog select#target').val();
	var text = jQuery('#button-dialog input#button-text').val();
	var title = jQuery('#button-dialog input#button-text').val();
	var size = jQuery('#button-dialog select#button-size').val();
	var shape = jQuery('#button-dialog select#button-shape').val();
	var bg_color = jQuery('#button-dialog input#button-color').val();		 	 
	var text_color = jQuery('#button-dialog input#text-color').val();
	var text_shadow = jQuery('#button-dialog input#text-shadow').val();	 	 	 
	 
	var output = '';
	output = '[button ';
	output += 'title="' + title + '" ';
	
	if(size)
		output += 'size="' + size + '" ';

	if(shape)
		output += 'shape="' + shape + '" ';

	output += 'bg_color="' + bg_color + '" ';	
	output += 'text_color="' + text_color + '" ';
	output += 'text_shadow="' + text_shadow + '" ';
	output += 'target="' + target + '" ';
	
	if(url)
		output += ' url=' + url;
	
	if(text) {	
		output += ']'+ text + '[/button]';
	}
	// if it is blank, use the selected text, if present
	else {
		output += ']'+ selectedText + '[/button]';
	}
	/** Send shortcode to editor */
	window.send_to_editor( output );
}



function insertColumns() {

	var selectedText = tinymce.activeEditor.selection.getContent();
	var output = ''; 

	
	
	output += '[box]'
	jQuery('#columns_holder>div').each( function() {

		
		
		var column = jQuery(this);
		var txt = column.find('textarea').val();
		var tablet = column.find('select#tablet').val();
		var mobile = column.find('select#mobile').val();

		
		if ( column.attr('class') == 'half' ) {
			
			if(txt) {	
				output += '[one_half tablet=' + tablet + ' mobile=' + mobile + ']' + txt + '[/one_half]';
			}
			// if it is blank, use the selected text, if present
			else {
				output += '[one_half tablet=' + tablet + ' mobile=' + mobile + ']' + selectedText + '[/one_half]';
			}
			
		}
		if ( column.attr('class') == 'third' ) {
			
			if(txt) {	
				output += '[one_third tablet= tablet=' + tablet + ' mobile=' + mobile + ']' + txt + '[/one_third]';
			}
			// if it is blank, use the selected text, if present
			else {
				output += '[one_third tablet=' + tablet + ' mobile=' + mobile + ']' + selectedText + '[/one_third]';
			}
		
			//output += '[one_third' + last + ']' + column.find('textarea').val() + '[/one_third]';
		}
		if ( column.attr('class') == 'two_third' ) {

			if(txt) {	
				output += '[two_third tablet=' + tablet + ' mobile=' + mobile + ']' + txt + '[/two_third]';
			}
			// if it is blank, use the selected text, if present
			else {
				output += '[two_third tablet=' + tablet + ' mobile=' + mobile + ']' + selectedText + '[/two_third]';
			}	
			
			//output += '[two_third' + last + ']' + column.find('textarea').val() + '[/two_third]';
		}
		if ( column.attr('class') == 'fourth' ) {
		
			if(txt) {	
				output += '[one_fourth tablet=' + tablet + ' mobile=' + mobile + ']' + txt + '[/one_fourth]';
			}
			// if it is blank, use the selected text, if present
			else {
				output += '[one_fourth tablet=' + tablet + ' mobile=' + mobile + ']' + selectedText + '[/one_fourth]';
			}	
		
			//output += '[one_fourth' + last + ']' + column.find('textarea').val() + '[/one_fourth]';
		}
		if ( column.attr('class') == 'three_fourth' ) {
		
			if(txt) {	
				output += '[three_fourth tablet=' + tablet + ' mobile=' + mobile + ']' + txt + '[/three_fourth]';
			}
			// if it is blank, use the selected text, if present
			else {
				output += '[three_fourth tablet=' + tablet + ' mobile=' + mobile + ']' + selectedText + '[/three_fourth]';
			}	
		
			//output += '[three_fourth' + last + ']' + column.find('textarea').val() + '[/three_fourth]';
		}
		
	});
	output += '[/box]'

	/** Send shortcode to editor */
	window.send_to_editor( output );
}

function insertBars() {

	var barstitle = jQuery('#animbar-dialog input#animbar-title').val();
	
	var output = ''; 
	output += '[bars barstitle="'+ barstitle +'"]';
	
	jQuery('#bars_holder .bar_item').each( function() {

		var title = jQuery(this).find('input.bar_item-title').val();
		var width = jQuery(this).find('input.bar_item-width').val();
		var color = jQuery(this).find('input.bar_item-color').val();
		
		output += '[bar title="' + title +'" width="'+ width +'" color="'+ color +'" /]';
		
	});
	
	output += '[/bars]';
	
	/** Send shortcode to editor */
	window.send_to_editor( output );
}

function insertPricetable() {

	var selectedText = tinymce.activeEditor.selection.getContent();
	
	
	if (jQuery('#pricetable-dialog input#pricetable-featured').is(":checked"))
	{
		var featured = 'true';
	}else{
		var featured = 'false';
	}
	
	var title = jQuery('#pricetable-dialog input#pricetable-title').val();
	var subtitle = jQuery('#pricetable-dialog input#pricetable-subtitle').val();
	var link = jQuery('#pricetable-dialog input#pricetable-link').val();
	var link_text = jQuery('#pricetable-dialog input#pricetable-linktext').val();
	var width = jQuery('#pricetable-dialog select#pricetable-width').val();
	var bg_color = jQuery('#pricetable-dialog input#bg-color').val();		 	 
	var text_color = jQuery('#pricetable-dialog input#text-color').val();		 	 
	var text_shadow = jQuery('#pricetable-dialog input#text-shadow').val();		 	 
		 
	 
	var output = '';
	
	// setup the output of shortcode
	output = '[pricetable ';
	
	output += 'featured="' + featured + '" ';
	output += 'title="' + title + '" ';
	output += 'subtitle="' + subtitle + '" ';
	output += 'link="' + link + '" ';
	output += 'link_text="' + link_text + '" ';
	output += 'width="' + width + '" ';
	output += 'bg_color="' + bg_color + '" ';
	output += 'text_color="' + text_color + '" ';
	output += 'text_shadow="' + text_shadow + '" ';

	output += ']'+ selectedText + '[/pricetable]';

	/** Send shortcode to editor */
	window.send_to_editor( output );
}

function insertList() {

	var selectedText = tinymce.activeEditor.selection.getContent();
	
	var style = jQuery('#list-dialog select#list_style').val(); 	  	 
		 
	style = style.replace('.png','');
	
	var output = '';
	output = '[list_style ';
	output += 'style="' + style + '" ';
	output += ']'+ selectedText + '[/list_style]';

	/** Send shortcode to editor */
	window.send_to_editor( output );
}


function insertQuote() {

	var selectedText = tinymce.activeEditor.selection.getContent();
	
	var text = jQuery('#other-dialog textarea#quote-text').val();
	var author = jQuery('#other-dialog input#quote-author').val();
	var align = jQuery('#other-dialog select#quote-align').val(); 	  	 
	 
	var output = '';
	output = '[insertquote ';
	output += 'author="' + author + '" ';
	output += 'style="' + align + '" ';
		
	if(text) {	
		output += ']'+ text + '[/insertquote]';
	}
	else {
		output += ']'+ selectedText + '[/insertquote]';
	}

	/** Send shortcode to editor */
	window.send_to_editor( output );
}

function insertHorizLine() {

	var output = '[horizontal_line]';

	/** Send shortcode to editor */
	window.send_to_editor( output );
	
}

function insertDropcap() {

	var selectedText = tinymce.activeEditor.selection.getContent();
	
	var text = jQuery('#other-dialog input#dropcap').val();	 	 
	var style = jQuery('#other-dialog select#dropcap-style').val(); 	  	 
		 
	var output = '';
	output = '[dropcap ';
	output += 'style="' + style + '" ';
		
	if(text) {	
		output += ']'+ text + '[/dropcap]';
	}
	else {
		output += ']'+ selectedText + '[/dropcap]';
	}
	/** Send shortcode to editor */
	window.send_to_editor( output );
}


function insertClearFloat() {

	var output = '[clear_float]';

	/** Send shortcode to editor */
	window.send_to_editor( output );
	
}

</script>

<?php echo get_template_directory();?>
	
<ul class="tabs">
	<li><a href="#gmap"><span>Google map</span></a></li>
	<li><a href="#video"><span>Video</span></a></li>
	<li><a href="#button"><span>Button</span></a></li>
	<li><a href="#columns"><span>Columns</span></a></li>
	<li><a href="#animbar"><span>Animated Bars</span></a></li>
	<li><a href="#pricetable"><span>Pricetable</span></a></li>
	<li><a href="#list"><span>List style</span></a></li>
	<li><a href="#other"><span>Other</span></a></li>
</ul>

<div class="tab_container">

	<!-- TAB - GOOGLE MAP -->	
	
	<div class="tab_content" id="gmap">

	<div id="gmap-dialog">
	
		<form action="/" method="get" accept-charset="utf-8">
			
			<h3>Insert Google map</h3>
			
			<div>
				<h4>Enter address (street, number, city, state), width and height for simple Google map.</h4>
			</div>
			
			<div>
				<label for="gmap-address">Address</label>
				<input type="text" name="gmap-address" value="" id="gmap-address" style="width:200px;"/>
			</div>
			
			<div>
				<label for="gmap-width">Map width <br /></label>
				<input type="text" name="gmap-width" value="100" id="gmap-width" />
				<select name="gmap-wunit" id="gmap-wunit">
					<option selected="%">%</option>
					<option value="px">px</option>
				</select>

			</div>			
			
			<div>
				<label for="gmap-height">Map height</label>
				<input type="text" name="gmap-height" value="400" id="gmap-height" />px
			</div>			

			<div class="insert">	
				<input type="button" id="insert-gmap" class="button-primary" value="<?php echo esc_attr__( 'Insert map shortcode', 'magnolia' ); ?>" onclick="insertGmap();" />
			</div>
			
			<div class="note">
			For more advanced use of Google Maps, install <a href="http://wordpress.org/extend/plugins/google-map-shortcode/"><b>Google Map Shortcode</b></a> plugin.
			</div>
			
		</form>
		
	</div><!-- #video-dialog --> 

	</div><!-- .tab_content #video --> 
	
	
	
	<!-- TAB - VIDEO SHORTCODE -->	
	
	<div class="tab_content" id="video">

	<div id="video-dialog">
	
		<form action="/" method="get" accept-charset="utf-8">
			
			<h3>Insert video</h3>
			
			<div>
				<label for="video-src">Select video site</label>
				<select name="video-src" id="video-src" size="1">
					<option value="youtube" selected="selected">You Tube</option>
					<option value="vimeo">Vimeo</option>
					<option value="screenr">Screenr</option>
					<option value="dailymotion">Daily Motion</option>
					<option value="yahoo">Yahoo</option>
					<option value="blip">Blip.tv</option>
					<option value="veoh">Veoh</option>
				</select>
			</div>	
			
			
			<div>
				<label for="video-id">Video ID</label>
				<input type="text" name="video-id" value="" id="video-id" />
			</div>
			
			<div>
				<label for="video-width">Video width</label>
				<input type="text" name="video-width" value="100" id="video-width" />
				<select name="video-wunit" id="video-wunit">
					<option selected="%">%</option>
					<option value="px">px</option>
				</select>
			</div>			
			
			<div>
				<label for="video-height">Video height</label>
				<input type="text" name="video-height" value="370" id="video-height" />
				<select name="video-hunit" id="video-hunit">
					<option value="%">%</option>
					<option selected="px">px</option>
				</select>
			</div>			

			<div class="insert">	
				<input type="button" id="insert-video" class="button-primary" value="<?php echo esc_attr__( 'Insert video shortcode', 'magnolia' ); ?>" onclick="insertVideo();" />
			</div>
			
		</form>
		
	</div><!-- #video-dialog --> 

	</div><!-- .tab_content #video --> 
	
	
	
	
	
	<!-- TAB - BUTTON SHORTCODE -->
	
	<div class="tab_content" id="button">

	<div id="button-dialog">
	
		<form action="/" method="get" accept-charset="utf-8">
			
			<h3>Insert button</h3>
			
			<div>
				<label for="button-url">Button URL</label>
				<input type="text" name="button-url" value="" id="button-url" />
			</div>
			
			<div>
				<label for="button-target">Target</label>
				<select name="target" id="target" size="1">
					<option selected="_self"=>Self</option>
					<option value="_blank">Blank</option>
				</select>
			</div>	
			
			<div>
				<label for="button-text">Button Text</label>
				<input type="text" name="button-text" value="" id="button-text" />
			</div>
			<div>
				<label for="button-size">Size</label>
				<select name="button-size" id="button-size" size="1">
					<option value="small">Small</option>
					<option value="" selected="selected">Medium</option>
					<option value="large">Large</option>
				</select>
			</div>

			<div>
				<label for="button-shape">Size</label>
				<select name="button-shape" id="button-shape" size="1">
					<option value="" selected="selected">Square</option>
					<option value="rounded">Rounded</option>					
					<option value="pill">Pill</option>
				</select>
			</div>

			<div>
				<label for="button-color">Button Color</label>
				<div id="button-color-selector" class="colorSelector">
					<div></div>
				</div>

				<input name="button-color" id="button-color" type="text" value="black" />
			
			</div>
			
			<div>
				<label for="text-color">Text Color</label>
				<div id="text-color-selector" class="colorSelector">
					<div></div>
				</div>

				<input name="text-color" id="text-color" type="text" value="white" />
			
			</div>

			<div>
				<label for="text-shadow">Text Shadow</label>
				<div id="text-shadow-selector" class="colorSelector">
					<div></div>
				</div>

				<input name="text-shadow" id="text-shadow" type="text" value="black" />
			
			</div>
			
			<div class="insert">	
				<input type="button" id="insert-button" class="button-primary" value="<?php echo esc_attr__( 'Insert button shortcode', 'aligator-shortcodes' ); ?>" onclick="insertButton();" />
			</div>
			
		</form>
		
	</div><!-- #button-dialog --> 

	</div><!-- .tab_content #button --> 
	

	
	<!-- TAB - COLUMNS SHORTCODE -->
	
	<div class="tab_content" id="columns">
	
		<div id="columns-dialog">
	
		<form action="/" method="get" accept-charset="utf-8">
			
			<h3>Insert columns</h3>
			
			<div class="button_holder">
				<input type="button" id="add_half" value="1/2 column" class="add_columns"/>
			</div>
			
			<div class="button_holder">
				<input type="button" id="add_third" value="1/3 column" class="add_columns" />
				<input type="button" id="add_two_third" value="2/3 column" class="add_columns" />
			</div>
			
			<div class="button_holder">
				<input type="button" id="add_fourth" value="1/4 column" class="add_columns" />
				<input type="button" id="add_three_fourth" value="3/4 column" class="add_columns" />
			</div>
			
			<div class="note">
			NOTE: insert only columns that fit into one row. Otherwise you layout may have "funny" gaps.
			</div>
			
			<div id="columns_holder">
				
			</div>

			<div class="insert">	
				<input type="button" id="insert-columns" class="button-primary" value="<?php echo esc_attr__( 'Insert columns shortcode', 'magnolia' ); ?>" onclick="insertColumns();" />
			</div>
		
		
		</form>
		
		</div><!-- #columns-dialog --> 
	
	</div><!-- .tab_content #custom-message--> 

	<!-- TAB - ANIM GRAPH BAR SHORTCODE -->
	
	<div class="tab_content" id="animbar">
		
		<div id="animbar-dialog">
	
			<form action="/" method="get" accept-charset="utf-8">
			
			<h3>Insert animated bars </h3>
						
			<div>
				<label for="animbar-title">Bars title</label>
				<input type="text" name="animbar-title" value="" id="animbar-title" />
			</div>
			
			
			<input type="button" id="add_bar" value="Click to add bar" />
			
			<div id="bars_holder">
			
				<div id="bar_item-1" class="bar_item add-remove-item">
					
					<div class="remove_bar_item"></div>
					<h4>Bar 1</h4>
					
					<div>
						<label>Title:</label>
						<input name="bar_item-title" class="bar_item-title" id="bar-title-1" type="text" value="" />
					</div>
					
					<div>
						<label>Width (in percent):</label>
						<input name="bar_item-width" class="bar_item-width" id="width-2" type="text" value="" />
					</div>	
					
					<div>
						<label for="bar-color">Bar Color</label>
						<div id="bar-color-1" class="colorSelector" style="margin-right: -10px;">
							<div></div>
						</div>

						<input name="bar_item-color" class="bar_item-color" id="input-bar_item-color-1" type="text" value="" />
					</div>	
					
					
					<div class="clear"></div>
				
				</div>
			
			</div>
			
			<div class="insert">	
				<input type="button" id="insert-bars" class="button-primary" value="<?php echo esc_attr__( 'Insert bars shortcode', 'ebony' ); ?>" onclick="insertBars();" />
			</div>			
			
			</form>
		
		</div><!-- #tabber-dialog --> 
		
	</div><!-- .tab_content #custom-message--> 
	

	<!-- TAB - PRICETABLE SHORTCODE -->
	
	<div class="tab_content" id="pricetable">

	<div id="pricetable-dialog">
	
		<form action="/" method="get" accept-charset="utf-8">
			
			<h3>Insert pricetable</h3>
			
			<div class="note">
			NOTE: DID YOU ALREADY SELECT THE CONTENT OF PRICE TABLE ? If not, the shortcode content will be empty
			</div>
			
			<div>
				<label for="pricetable-featured">Featured ?</label>
				<input value="true" type="checkbox" name="pricetable-featured" id="pricetable-featured">
			</div>
			
			
			<div>
				<label for="pricetable-title">Title</label>
				<input type="text" name="pricetable-title" value="" id="pricetable-title" />
			</div>
			
			<div>
				<label for="pricetable-subtitle">Subitle</label>
				<input type="text" name="pricetable-subtitle" value="" id="pricetable-subtitle" />
			</div>
				
			
			<div>
				<label for="pricetable-link">Pricetable link</label>
				<input type="text" name="pricetable-link" value="" id="pricetable-link" />
			</div>
			
			<div>
				<label for="pricetable-linktext">Link text</label>
				<input type="text" name="pricetable-linktext" value="" id="pricetable-linktext" />
			</div>			
			
			<div>
				<label for="pricetable-width">Width</label>
				<select name="pricetable-width" id="pricetable-width" size="1">
					<option value="half" selected="selected">One half</option>
					<option value="third"=>One third</option>
					<option value="fourth">One fourth</option>
					<option value="fifth">One fifth</option>
					<option value="sixth">One sixth</option>
				</select>
			</div>		

			<div>
				<label for="bg-color">Background Color</label>
				<div id="bg-color-selector" class="colorSelector">
					<div></div>
				</div>

				<input name="bg-color" id="bg-color" type="text" value="gainsboro" />
			
			</div>
			
			<div>
				<label for="text-color">Text Color</label>
				<div id="text-color-selector" class="colorSelector">
					<div></div>
				</div>

				<input name="text-color" id="text-color" type="text" value="dimgrey" />
			
			</div>
			
			
			<div>
				<label for="text-shadow">Text Shadow Color</label>
				<div id="text-shadow-selector" class="colorSelector">
					<div></div>
				</div>

				<input name="text-shadow" id="text-shadow" type="text" value="white" />
			
			</div>
			
			<div class="insert">	
				<input type="button" id="insert-pricetable" class="button-primary" value="<?php echo esc_attr__( 'Insert pricetable shortcode', 'ebony' ); ?>" onclick="insertPricetable();" />
			</div>
			
		</form>
		
		</div><!-- #pricetable-dialog --> 

	</div><!-- .tab_content #button --> 

		<!-- TAB - LIST STYLE SHORTCODE -->
	
	<div class="tab_content" id="list">
	
		<div  id="list-dialog">
		
			<h3>Insert styled list</h3>
			
			<div class="note">
			NOTE: DID YOU ALREADY SELECT THE LIST TO CHANGE ITS STYLE ? If not, the shortcode content will be empty
			</div>
			
			
			<form action="/" method="get" accept-charset="utf-8">
			
			<div>
				
				<label for="custom-mess-icon">Choose icon</label>
				
				<div id="list_image_holder" style="float: left; width: auto; padding: 0 10px; margin-top: -10px;"></div>
				
				<input type="hidden" name="path_to_liststyles" id="path_to_liststyles" value="<?php echo plugins_url(). '/aligator-shortcodes/images/liststyles/'; ?>">
				
				<?php
				//Images Reader
				//$iterator = new DirectoryIterator(dirname(__FILE__));
				//$path = $iterator->getPath();
				//$path = dirname(__FILE__);
				//$images_path = $path . '/images/liststyles';

				$listicons_path = plugin_dir_path(__FILE__). '/images/liststyles/';

				$images = array();
				
				if ( is_dir($listicons_path) ) {
					if ( $images_dir = opendir($listicons_path) ) { 
						while ( ($images_file = readdir($images_dir) ) !== false ) {
							if( stristr($images_file, ".png") !== false || stristr($images_file, ".jpg") !== false ) {
								$images[] = $images_file;
							}
						}    
					}
				};
				
				echo '<select name="list_style" id="list_style" size="1"><option value="" selected="selected">None</option>';
				foreach ($images as $icon) {
					
					echo '<option value="'. $icon.'">'. $icon .'</option>';

				
				}
				echo '</select>';
				?>
				
			</div>
		
			<div class="insert">	
				<input type="button" id="insert-list" class="button-primary" value="<?php echo esc_attr__( 'Insert list shortcode', 'aligator-shortcodes' ); ?>" onclick="insertList();" />
			</div>
		
		</form>
		
		</div><!-- #list-dialog--> 
	
	</div><!-- .tab_content #list--> 

	<!-- TAB - OTHER ELEMENTS SHORTCODE -->
	
	<div class="tab_content" id="other">
		
		<div id="other-dialog">
	
			<form action="/" method="get" accept-charset="utf-8">
			
			<h3>Insert quote</h3>
			
			<div>
				<label for="quote-text">Quoted text</label>
				<textarea id="quote-text"></textarea>
			</div>
			
			<div>
				<label for="quote-text">Quote author</label>
				<input name="quote-author" id="quote-author" type="text" value="" />
			</div>
			
			
			
			<div>
				<label for="quote-align">Alignment</label>
				<select name="quote-align" id="quote-align" size="1">
					<option value="left" selected="selected">Left</option>
					<option value="right">Right</option>
					<option value="center">Center</option>
				</select>
			</div>
		
			
			<div class="insert">	
				<input type="button" id="insert-quote" class="button-primary" value="<?php echo esc_attr__( 'Insert quote shortcode', 'magnolia' ); ?>" onclick="insertQuote();" />
			</div>			
			
			</form>
			
			
			<hr>
			
			<form action="/" method="get" accept-charset="utf-8">
			
				<h3 style="float:left">Insert horizontal line</h3>
				
				<div class="insert">	
					<input type="button" id="insert-clear-float" class="button-primary" value="<?php echo esc_attr__( 'Insert horizontal line', 'magnolia' ); ?>" onclick="insertHorizLine();" />
				</div>
			
			</form>
			
			<hr>
			
			<form action="/" method="get" accept-charset="utf-8">
			
			<h3>Insert dropcap</h3>
			
				<div>
					<label for="dropcap">Dropcap letter</label>
					<input type="text" name="dropcap" value="" id="dropcap" />
				</div>
					
				<div>
					<label for="dropcap-style">Style</label>
					<select name="dropcap-style" id="dropcap-style" size="1">
						<option value="light" selected="selected">Light</option>
						<option value="dark">Dark</option>
					</select>
				</div>
					
				<div class="insert">	
					<input type="button" id="insert-dropcap" class="button-primary" value="<?php echo esc_attr__( 'Insert dropcap shortcode', 'magnolia' ); ?>" onclick="insertDropcap();" />
				</div>			
			
			</form>
			
			<hr>
			
			<form action="/" method="get" accept-charset="utf-8">
			
			<h3 style="float:left">Clear float</h3>
			
			<div class="insert">	
				<input type="button" id="insert-clear-float" class="button-primary" value="<?php echo esc_attr__( 'Insert clear float shortcode', 'magnolia' ); ?>" onclick="insertClearFloat();" />
			</div>
			
			</form>
		
		</div><!-- #other-dialog --> 
		
		
	</div><!-- .tab_content #other--> 

	
</div><!-- .tab_container --> 