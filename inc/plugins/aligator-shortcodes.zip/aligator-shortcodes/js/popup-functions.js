jQuery(document).ready(function($){
	
	$('.colorSelector').each(function(){
		var Othis = this; //cache a copy of the this variable for use inside nested function
			
		$(this).ColorPicker({
				color: 'ffcc00',
				onShow: function (colpkr) {
					$(colpkr).fadeIn(500);
					return false;
				},
				onHide: function (colpkr) {
					$(colpkr).fadeOut(500);
					return false;
				},
				onChange: function (hsb, hex, rgb) {
					$(Othis).children('div').css('backgroundColor', '#' + hex);
					$(Othis).next('input').attr('value','#' + hex);
				}
		});
			  
	}); //end color picker
	
	
	$('#TB_ajaxContent').height($(this).parent().height());
	
	/* */
	if( $('#TB_window').length ) {
		$('#TB_window').resize(function(e){
			
			$(this).find('#TB_ajaxContent').height( $(this).height() - 50 );
			$(this).find('#TB_ajaxContent').width( $(this).width());
			
		});
	}
	 

	/* POPUP HOLDER - to avoid duplicates on Add toggle, Add acordion, Add tab ... */
	var popUpHolder = '#TB_ajaxContent';
	
	/* TinyMce tabs*/
	
	$(".tab_content").hide(); //Hide all content
	$("ul.tabs li:first").addClass("active").show(); //Activate first tab
	$(".tab_content:first").show(); //Show first tab content
	$("ul.tabs li").click(function() {

		$("ul.tabs li").removeClass("active"); //Remove any "active" class
		$(this).addClass("active"); //Add "active" class to selected tab
		$(".tab_content").hide(); //Hide all tab content

		var activeTab = $(this).find("a").attr("href"); //Find the href attribute value to identify the active tab + content
		$(activeTab).fadeIn(); //Fade in the active ID content
		return false;
	});
	
		
	
	/* ========= Columns ======== */
	$( '#add_half').click(function() {
		$(this).parent().parent().find('#columns_holder').append('<div class="half"><div class="remove_column" id="remove_column"></div><textarea></textarea><div>Tablet size:<br /><select name="tablet" id="tablet"><option selected="50">default</option><option value="100">full width</option></select></div><div>Mobile size:<br /><select name="mobile" id="mobile"><option value="50">default</option><option value="100">full width</option></select></div></div>');
	});
	$( '#add_third').click(function() {
		$(this).parent().parent().find('#columns_holder').append('<div class="third"><div class="remove_column" id="remove_column"></div><textarea></textarea><div>Tablet size:<br /><select name="tablet" id="tablet"><option selected="33">default</option><option value="100">full width</option><option value="50">one half</option></select></div><div>Mobile size:<br /><select name="mobile" id="mobile"><option selected="33">default</option><option value="100">full width</option><option value="50">one half</option></select></div></div>');
	});
	$( '#add_two_third').click(function() {
		$(this).parent().parent().find('#columns_holder').append('<div class="two_third"><div class="remove_column" id="remove_column"></div><textarea></textarea><div>Tablet size:<br /><select name="tablet" id="tablet"><option selected="66">default</option><option value="100">full width</option><option value="50">one half</option></select></div><div>Mobile size:<br /><select name="mobile" id="mobile"><option selected="66">default</option><option value="100">full width</option><option value="50">one half</option></select></div></div>');
	});
	$( '#add_fourth').click(function() {
		$(this).parent().parent().find('#columns_holder').append('<div class="fourth"><div class="remove_column" id="remove_column"></div><textarea></textarea><div>Tablet size:<br /><select name="tablet" id="tablet"><option selected="25">default</option><option value="100">full width</option><option value="50">one half</option></select></div><div>Mobile size:<br /><select name="mobile" id="mobile"><option selected="25">default</option><option value="100">full width</option><option value="50">one half</option></select></div></div>');
	});
	$( '#add_three_fourth').click(function() {
		$('#columns_holder').append('<div class="three_fourth"><div class="remove_column" id="remove_column"></div><textarea></textarea><div>Tablet size:<br /><select name="tablet" id="tablet"><option selected="75">default</option><option value="100">full width</option><option value="50">one half</option></select></div><div>Mobile size:<br /><select name="mobile" id="mobile"><option selected="75">default</option><option value="100">full width</option><option value="50">one half</option></select></div></div>');
		
	});
	$('.remove_column').live('click', function() {
		$(this).parent().remove();
		return false;
	});
	/* ========= end Columns ======== */


	
		
	/* ========= Animated Bars ======== */
	var count_Bar = 1;
	
	$( '#add_bar').click(function() {
		
		//count_Bar = $('#tabber_holder').children('div').length +1 ;
		count_Bar ++;
		
		$('#bars_holder').append('<div id="bar_item-' + count_Bar + '" class="bar_item add-remove-item"><div class="remove_bar_item" id="remove-' + count_Bar+ '"></div><h4>Bar ' + count_Bar + '</h4><label>Title:</label><input class="bar_item-title" name="bar_item-title" id="bar-title-' + count_Bar + '" type="text" value="Enter title" /><label>Width (in percent):</label><input name="bar_item-width" class="bar_item-width" id="width-'+ count_Bar +'" type="text" value="" /><div><label for="bar-color">Bar Color</label><div id="bar-color-'+count_Bar+'" class="colorSelector"><div></div></div><input name="bar_item-color" class="bar_item-color" id="input-bar_item-color-'+ count_Bar +'" type="text" value="" /></div><div class="clear"></div></div>');
	
		var thisSelector = $('#bar-color-'+ count_Bar + '');
		thisSelector.ColorPicker(
		{
				color: 'ffcc00',
				onShow: function (colpkr) {
					$(colpkr).fadeIn(500);
					return false;
				},
				onHide: function (colpkr) {
					$(colpkr).fadeOut(500);
					return false;
				},
				onChange: function (hsb, hex, rgb) {
					$(thisSelector).children('div').css('backgroundColor', '#' + hex);
					$(thisSelector).next('input').attr('value','#' + hex);
				}
		}
		
		);
	
	});
	$('.remove_bar_item').live('click', function() {
		$(this).parent().remove();
		return false;
	});
	

	
	
	/* ========= List Style selector =========*/
	var liststyle_icon_path = $('input#path_to_liststyles').val();
	$("select#list_style").change(function () {
	
		var icon = $(this).val(); 
		
		$("select#list_style option:selected").each(function () {
		
			if (icon == '') {
				$("#list_image_holder").html('<i>No icon is selected for custom message box</i>');
			}else{
				$("#list_image_holder").html('<img src="'+ liststyle_icon_path + icon +'" />');
			}
			
		});

        })
        .change();
	/* ========= end List Style selector =========*/
	
}); //end doc ready