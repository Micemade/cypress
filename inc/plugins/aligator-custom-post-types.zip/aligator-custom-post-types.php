<?php
/*
Plugin Name: Aligator Custom Post Types
Plugin URI: http://aligator-studio.com
Description: Custom Post Types plugin for Aligator Studio WP themes
Version: 1.0.0
Author: Aligator Studio
Author URI: http://aligator-studio.com
*/



function myplugin_activate() {
	// register taxonomies/post types here
	flush_rewrite_rules();
}

register_activation_hook( __FILE__, 'myplugin_activate' );

function myplugin_deactivate() {
	flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'myplugin_deactivate' );



/**
 *	Register custom post type and custom taxonomy
 *
 */
//

function filter_portfolio_cpt_link($link, $post) {
    if ($post->post_type != 'portfolio')
        return $link;
    if ($cats = get_the_terms($post->ID, 'portfolio_category')){
        $link = str_replace('%portfolio_category%', array_pop($cats)->slug, $link);
    }else{
		$link = str_replace('%portfolio_category%/', '', $link);
	}
	return $link;
}

add_filter('post_type_link', 'filter_portfolio_cpt_link', 10, 2);





function portfolio_post_type_activation() {
	portfolio_post_type();
}

add_action('init', 'portfolio_post_type_activation' );


/**
 *	Portfolio post type
 *
 */


function portfolio_post_type() {



	/**
	 * Enable the portfolio custom post type
	 * http://codex.wordpress.org/Function_Reference/register_post_type
	 */


	$labels = array(
		'name' => __( 'Portfolio', 'aligator-custom-post-types' ),
		'singular_name' => __( 'Portfolio Item', 'aligator-custom-post-types' ),
		'add_new' => __( 'Add New Item', 'aligator-custom-post-types' ),
		'add_new_item' => __( 'Add New Portfolio Item', 'aligator-custom-post-types' ),
		'edit_item' => __( 'Edit Portfolio Item', 'aligator-custom-post-types' ),
		'new_item' => __( 'Add New Portfolio Item', 'aligator-custom-post-types' ),
		'view_item' => __( 'View Item', 'aligator-custom-post-types' ),
		'search_items' => __( 'Search Portfolio', 'aligator-custom-post-types' ),
		'not_found' => __( 'No Portfolio items found', 'aligator-custom-post-types' ),
		'not_found_in_trash' => __( 'No Portfolio items found in trash', 'aligator-custom-post-types' )
	);

	$args = array(
    	'labels' => $labels,
    	'public' => true,
		'supports' => array( 'title', 'editor', 'thumbnail', 'comments','post-formats' ),
		'capability_type' => 'post',
		'rewrite' => array("slug" => "portfolio/%portfolio_category%", 'with_front' => true, 'pages'=> true), // Permalinks format
		'menu_position' => 5,
		'has_archive' => 'portfolio',
		'hierarchical' => false,
		'menu_icon' => ''
	); 

	register_post_type( 'portfolio', $args );
	


	/**
	 * Register a taxonomy for portfolio Tags
	 * http://codex.wordpress.org/Function_Reference/register_taxonomy
	 */
	 

	
	$taxonomy_portfolio_tag_labels = array(
		'name' => _x( 'Portfolio Tags','admin_labels', 'aligator-custom-post-types' ),
		'singular_name' => _x( 'Portfolio Tag','admin_labels', 'aligator-custom-post-types' ),
		'search_items' => _x( 'Search Portfolio Tags','admin_labels', 'aligator-custom-post-types' ),
		'popular_items' => _x( 'Popular Portfolio Tags','admin_labels', 'aligator-custom-post-types' ),
		'all_items' => _x( 'All Portfolio Tags','admin_labels', 'aligator-custom-post-types' ),
		'parent_item' => _x( 'Parent Portfolio Tag','admin_labels', 'aligator-custom-post-types' ),
		'parent_item_colon' => _x( 'Parent Portfolio Tag:','admin_labels', 'aligator-custom-post-types' ),
		'edit_item' => _x( 'Edit Portfolio Tag','admin_labels', 'aligator-custom-post-types' ),
		'update_item' => _x( 'Update Portfolio Tag','admin_labels', 'aligator-custom-post-types' ),
		'add_new_item' => _x( 'Add New portfolio Tag','admin_labels', 'aligator-custom-post-types' ),
		'new_item_name' => _x( 'New Portfolio Tag Name','admin_labels', 'aligator-custom-post-types' ),
		'separate_items_with_commas' => _x( 'Separate Portfolio tags with commas','admin_labels', 'aligator-custom-post-types' ),
		'add_or_remove_items' => _x( 'Add or remove Portfolio tags','admin_labels', 'aligator-custom-post-types' ),
		'choose_from_most_used' => _x( 'Choose from the most used Portfolio tags','admin_labels', 'aligator-custom-post-types' ),
		'menu_name' => _x( 'Portfolio Tags','admin_labels', 'aligator-custom-post-types' )
	);
	
	$taxonomy_portfolio_tag_args = array(
		'labels' => $taxonomy_portfolio_tag_labels,
		'public' => true,
		'show_in_nav_menus' => true,
		'show_ui' => true,
		'show_tagcloud' => true,
		'hierarchical' => false,
		'rewrite' => true,
		'query_var' => true
	);
	
	register_taxonomy( 'portfolio_tag', array( 'portfolio' ), $taxonomy_portfolio_tag_args );
	


	/**
	 * Register a taxonomy for portfolio Categories
	 * http://codex.wordpress.org/Function_Reference/register_taxonomy
	 */


    $taxonomy_portfolio_category_labels = array(
		'name' => _x( 'Portfolio Categories','admin_labels', 'aligator-custom-post-types' ),
		'singular_name' => _x( 'Portfolio Category','admin_labels', 'aligator-custom-post-types' ),
		'search_items' => _x( 'Search portfolio Categories','admin_labels', 'aligator-custom-post-types' ),
		'popular_items' => _x( 'Popular Portfolio Categories','admin_labels', 'aligator-custom-post-types' ),
		'all_items' => _x( 'All Portfolio Categories','admin_labels', 'aligator-custom-post-types' ),
		'parent_item' => _x( 'Parent Portfolio Category','admin_labels', 'aligator-custom-post-types' ),
		'parent_item_colon' => _x( 'Parent Portfolio Category:','admin_labels', 'aligator-custom-post-types' ),
		'edit_item' => _x( 'Edit Portfolio Category','admin_labels', 'aligator-custom-post-types' ),
		'update_item' => _x( 'Update Portfolio Category','admin_labels', 'aligator-custom-post-types' ),
		'add_new_item' => _x( 'Add New Portfolio Category','admin_labels', 'aligator-custom-post-types' ),
		'new_item_name' => _x( 'New Portfolio Category Name','admin_labels', 'aligator-custom-post-types' ),
		'separate_items_with_commas' => _x( 'Separate Portfolio categories with commas','admin_labels', 'aligator-custom-post-types' ),
		'add_or_remove_items' => _x( 'Add or remove Portfolio categories','admin_labels', 'aligator-custom-post-types' ),
		'choose_from_most_used' => _x( 'Choose from the most used Portfolio categories','admin_labels', 'aligator-custom-post-types' ),
		'menu_name' => _x( 'Portfolio Categories','admin_labels', 'aligator-custom-post-types' ),
    );
	
    $taxonomy_portfolio_category_args = array(
		'labels' => $taxonomy_portfolio_category_labels,
		'public' => true,
		'show_in_nav_menus' => true,
		'show_ui' => true,
		'show_tagcloud' => true,
		'hierarchical' => true,
		'rewrite' => array( 'slug' => 'portfolio' ),
		'query_var' => true
    );
	
    register_taxonomy( 'portfolio_category', array( 'portfolio' ), $taxonomy_portfolio_category_args );
	
}



//add_action( 'init', 'portfolio_post_type' );

// Allow thumbnails to be used on portfolio post type
//add_theme_support( 'post-thumbnails', array( 'portfolio' ) );
 
/**
 * Add Columns to portfolio Edit Screen
 * http://wptheming.com/2010/07/column-edit-pages/
 */
 

function portfolio_post_type_edit_columns($portfolio_columns){
	$portfolio_columns = array(
		"cb" => "<input type=\"checkbox\" />",
		"title" => _x('Title', 'column name','aligator-custom-post-types'),
		"thumbnail" => __('Thumbnail', 'aligator-custom-post-types'),
		"portfolio_category" => __('Portfolio category', 'aligator-custom-post-types'),
		"portfolio_tag" => __('Tags', 'aligator-custom-post-types'),
		"author" => __('Author', 'aligator-custom-post-types'),
		"comments" => __('Comments', 'aligator-custom-post-types'),
		"date" => __('Date', 'aligator-custom-post-types'),
	);
	$portfolio_columns['comments'] = '<div class="vers"><img alt="Comments" src="' . esc_url( admin_url( 'images/comment-grey-bubble.png' ) ) . '" /></div>';
	return $portfolio_columns;
}

add_filter( 'manage_edit-portfolio_columns', 'portfolio_post_type_edit_columns' );
 
function portfolio_post_type_columns_display($portfolio_columns, $post_id){

	switch ( $portfolio_columns )
	
	{
		// Code from: http://wpengineer.com/display-post-thumbnail-post-page-overview
		/* 
		case "thumbnail":
		$width = (int) 35;
		$height = (int) 35;
		$thumbnail_id = get_post_meta( $post_id, '_thumbnail_id', true );
		
		// Display the featured image in the column view if possible
		if ($thumbnail_id) {
			$thumb = wp_get_attachment_image( $thumbnail_id, array($width, $height), true );
		}
		if ( isset($thumb) ) {
			echo $thumb;
		} else {
			echo __('None', 'aligator-custom-post-types');
		}
		break;
		*/
		
		// Display the portfolio tags in the column view
		case "portfolio_category":
		
		if ( $category_list = get_the_term_list( $post_id, 'portfolio_category', '', ', ', '' ) ) {
			echo $category_list;
		} else {
			echo __('None', 'aligator-custom-post-types');
		}
		break;	
		
		// Display the portfolio tags in the column view
		case "portfolio_tag":
		
		if ( $tag_list = get_the_term_list( $post_id, 'portfolio_tag', '', ', ', '' ) ) {
			echo $tag_list;
		} else {
			echo __('None', 'aligator-custom-post-types');
		}
		break;			
	}
}

add_action( 'manage_posts_custom_column',  'portfolio_post_type_columns_display', 10, 2 );



/**
 * Add portfolio count to "Right Now" Dashboard Widget
 */


function add_portfolio_counts() {
        if ( ! post_type_exists( 'portfolio' ) ) {
             return;
        }

        $num_posts = wp_count_posts( 'portfolio' );
        $num = number_format_i18n( $num_posts->publish );
        $text = _n( 'portfolio Item', 'portfolio Items', intval($num_posts->publish) );
        if ( current_user_can( 'edit_posts' ) ) {
            $num = "<a href='edit.php?post_type=portfolio'>$num</a>";
            $text = "<a href='edit.php?post_type=portfolio'>$text</a>";
        }
        echo '<td class="first b b-portfolio">' . $num . '</td>';
        echo '<td class="t portfolio">' . $text . '</td>';
        echo '</tr>';

        if ($num_posts->pending > 0) {
            $num = number_format_i18n( $num_posts->pending );
            $text = _n( 'portfolio Item Pending', 'portfolio Items Pending', intval($num_posts->pending) );
            if ( current_user_can( 'edit_posts' ) ) {
                $num = "<a href='edit.php?post_status=pending&post_type=portfolio'>$num</a>";
                $text = "<a href='edit.php?post_status=pending&post_type=portfolio'>$text</a>";
            }
            echo '<td class="first b b-portfolio">' . $num . '</td>';
            echo '<td class="t portfolio">' . $text . '</td>';

            echo '</tr>';
        }
}

add_action( 'right_now_content_table_end', 'add_portfolio_counts' );



/**
 * Add contextual help menu
 */
 

function portfolio_post_type_add_help_text( $contextual_help, $screen_id, $screen ) { 
	if ( 'portfolio' == $screen->id ) {
		$contextual_help =
		'<p>' . __('The title field and the big Post Editing Area are fixed in place, but you can reposition all the other boxes using drag and drop, and can minimize or expand them by clicking the title bar of each box. Use the Screen Options tab to unhide more boxes (Excerpt, Send Trackbacks, Custom Fields, Discussion, Slug, Author) or to choose a 1- or 2-column layout for this screen.', 'aligator-custom-post-types') . '</p>' .
		'<p>' . __('<strong>Title</strong> - Enter a title for your post. After you enter a title, you&#8217;ll see the permalink below, which you can edit.', 'aligator-custom-post-types') . '</p>' .
		'<p>' . __('<strong>Post editor</strong> - Enter the text for your post. There are two modes of editing: Visual and HTML. Choose the mode by clicking on the appropriate tab. Visual mode gives you a WYSIWYG editor. Click the last icon in the row to get a second row of controls. The HTML mode allows you to enter raw HTML along with your post text. You can insert media files by clicking the icons above the post editor and following the directions. You can go the distraction-free writing screen, new in 3.2, via the Fullscreen icon in Visual mode (second to last in the top row) or the Fullscreen button in HTML mode (last in the row). Once there, you can make buttons visible by hovering over the top area. Exit Fullscreen back to the regular post editor.', 'aligator-custom-post-types') . '</p>' .
		'<p>' . __('<strong>Publish</strong> - You can set the terms of publishing your post in the Publish box. For Status, Visibility, and Publish (immediately), click on the Edit link to reveal more options. Visibility includes options for password-protecting a post or making it stay at the top of your blog indefinitely (sticky). Publish (immediately) allows you to set a future or past date and time, so you can schedule a post to be published in the future or backdate a post.', 'aligator-custom-post-types') . '</p>' .
		( ( current_theme_supports( 'post-formats' ) && post_type_supports( 'post', 'post-formats' ) ) ? '<p>' . __( '<strong>Post Format</strong> - This designates how your theme will display a specific post. For example, you could have a <em>standard</em> blog post with a title and paragraphs, or a short <em>aside</em> that omits the title and contains a short text blurb. Please refer to the Codex for <a href="http://codex.wordpress.org/Post_Formats#Supported_Formats">descriptions of each post format</a>. Your theme could enable all or some of 10 possible formats.' ) . '</p>' : '' ) .
		'<p>' . __('<strong>Featured Image</strong> - This allows you to associate an image with your post without inserting it. This is usually useful only if your theme makes use of the featured image as a post thumbnail on the home page, a custom header, etc.', 'aligator-custom-post-types') . '</p>' .
		'<p>' . __('<strong>Send Trackbacks</strong> - Trackbacks are a way to notify legacy blog systems that you&#8217;ve linked to them. Enter the URL(s) you want to send trackbacks. If you link to other WordPress sites they&#8217;ll be notified automatically using pingbacks, and this field is unnecessary.', 'aligator-custom-post-types') . '</p>' .
		'<p>' . __('<strong>Discussion</strong> - You can turn comments and pings on or off, and if there are comments on the post, you can see them here and moderate them.', 'aligator-custom-post-types') . '</p>' .
		'<p><strong>' . __('For more information:', 'aligator-custom-post-types') . '</strong></p>' .
		'<p>' . __('<a href="http://codex.wordpress.org/Posts_Add_New_Screen" target="_blank">Documentation on Writing and Editing Posts</a>', 'aligator-custom-post-types') . '</p>' .
		'<p>' . __('<a href="http://wordpress.org/support/" target="_blank">Support Forums</a>', 'aligator-custom-post-types') . '</p>';
  } elseif ( 'edit-portfolio' == $screen->id ) {
    $contextual_help = 
	    '<p>' . __('You can customize the display of this screen in a number of ways:', 'aligator-custom-post-types') . '</p>' .
		'<ul>' .
		'<li>' . __('You can hide/display columns based on your needs and decide how many posts to list per screen using the Screen Options tab.', 'aligator-custom-post-types') . '</li>' .
		'<li>' . __('You can filter the list of posts by post status using the text links in the upper left to show All, Published, Draft, or Trashed posts. The default view is to show all posts.', 'aligator-custom-post-types') . '</li>' .
		'<li>' . __('You can view posts in a simple title list or with an excerpt. Choose the view you prefer by clicking on the icons at the top of the list on the right.', 'aligator-custom-post-types') . '</li>' .
		'<li>' . __('You can refine the list to show only posts in a specific category or from a specific month by using the dropdown menus above the posts list. Click the Filter button after making your selection. You also can refine the list by clicking on the post author, category or tag in the posts list.', 'aligator-custom-post-types') . '</li>' .
		'</ul>' .
		'<p>' . __('Hovering over a row in the posts list will display action links that allow you to manage your post. You can perform the following actions:', 'aligator-custom-post-types') . '</p>' .
		'<ul>' .
		'<li>' . __('Edit takes you to the editing screen for that post. You can also reach that screen by clicking on the post title.', 'aligator-custom-post-types') . '</li>' .
		'<li>' . __('Quick Edit provides inline access to the metadata of your post, allowing you to update post details without leaving this screen.', 'aligator-custom-post-types') . '</li>' .
		'<li>' . __('Trash removes your post from this list and places it in the trash, from which you can permanently delete it.', 'aligator-custom-post-types') . '</li>' .
		'<li>' . __('Preview will show you what your draft post will look like if you publish it. View will take you to your live site to view the post. Which link is available depends on your post&#8217;s status.', 'aligator-custom-post-types') . '</li>' .
		'</ul>' .
		'<p>' . __('You can also edit multiple posts at once. Select the posts you want to edit using the checkboxes, select Edit from the Bulk Actions menu and click Apply. You will be able to change the metadata (categories, author, etc.) for all selected posts at once. To remove a post from the grouping, just click the x next to its name in the Bulk Edit area that appears.', 'aligator-custom-post-types') . '</p>' .
		'<p><strong>' . __('For more information:', 'aligator-custom-post-types') . '</strong></p>' .
		'<p>' . __('<a href="http://codex.wordpress.org/Posts_Screen" target="_blank">Documentation on Managing Posts</a>', 'aligator-custom-post-types') . '</p>' .
		'<p>' . __('<a href="http://wordpress.org/support/" target="_blank">Support Forums</a>', 'aligator-custom-post-types') . '</p>';

  }
  return $contextual_help;
}

add_action( 'contextual_help', 'portfolio_post_type_add_help_text', 10, 3 );



/**
 * Displays the custom post type icon in the dashboard
 */


function portfolio_post_type_portfolio_icons() { 
   
	global $wp_version;
	if( version_compare( $wp_version, '3.8', '>=') ) {
	?>
		<style type="text/css" media="screen">
		#adminmenu .menu-icon-portfolio div.wp-menu-image:before {
			content: "\f322";
		}
		</style>
	
	<?php }else{ ?>
	
	<style type="text/css" media="screen">
	#menu-posts-portfolio .wp-menu-image {
		background: url(<?php echo plugins_url( '/images/portfolio-icon.png', __FILE__ ) ?>) no-repeat 6px 6px !important;
	}
	#menu-posts-portfolio:hover .wp-menu-image, #menu-posts-portfolio.wp-has-current-submenu .wp-menu-image {
		background-position:6px -16px !important;
	}
	#icon-edit.icon32-posts-portfolio {background: url(<?php echo plugins_url( '/images/portfolio-32x32.png', __FILE__ ) ?>) no-repeat;}
	 */
	#adminmenu .menu-icon-portfolio div.wp-menu-image:before {
		content: "\f322";
	}
   </style>
   
   <?php }; ?>
   
<?php }

add_action( 'admin_head', 'portfolio_post_type_portfolio_icons' );



/**
 * Slide custom post type
 */


function slide_post_type_activation() {
	slide_post_type();
}

add_action('init', 'slide_post_type_activation' );

function slide_post_type() {

	/**
	 * Enable the slide custom post type
	 * http://codex.wordpress.org/Function_Reference/register_post_type
	 */

	$labels = array(
		'name' => __( 'Slide', 'aligator-custom-post-types' ),
		'singular_name' => __( 'Slide Item', 'aligator-custom-post-types' ),
		'add_new' => __( 'Add New Slide', 'aligator-custom-post-types' ),
		'add_new_item' => __( 'Add New Slide Item', 'aligator-custom-post-types' ),
		'edit_item' => __( 'Edit Slide Item', 'aligator-custom-post-types' ),
		'new_item' => __( 'Add New Slide Item', 'aligator-custom-post-types' ),
		'view_item' => __( 'View Slide', 'aligator-custom-post-types' ),
		'search_items' => __( 'Search Slide items', 'aligator-custom-post-types' ),
		'not_found' => __( 'No Slide items found', 'aligator-custom-post-types' ),
		'not_found_in_trash' => __( 'No Slide items found in trash', 'aligator-custom-post-types' )
	);

	$args = array(
    	'labels' => $labels,
    	'public' => true,
		'supports' => array( 'title', 'excerpt', 'thumbnail' ),
		'capability_type' => 'post',
		'rewrite' => array("slug" => "slide"), // Permalinks format
		'menu_position' => 20,
		'has_archive' => true,
		'menu_icon' => ''
	); 

	register_post_type( 'slide', $args );
	

	
	/**
	 * Register a taxonomy for slide Categories
	 * http://codex.wordpress.org/Function_Reference/register_taxonomy
	 */

    $taxonomy_slider_labels = array(
		'name' => _x( 'Sliders','admin_labels', 'aligator-custom-post-types' ),
		'singular_name' => _x( 'Slider','admin_labels', 'aligator-custom-post-types' ),
		'search_items' => _x( 'Search Sliders','admin_labels', 'aligator-custom-post-types' ),
		'popular_items' => _x( 'Popular Sliders','admin_labels', 'aligator-custom-post-types' ),
		'all_items' => _x( 'All Sliders','admin_labels', 'aligator-custom-post-types' ),
		//'parent_item' => _x( 'Parent Slider','admin_labels', 'aligator-custom-post-types' ),
		//'parent_item_colon' => _x( 'Parent Slider:','admin_labels', 'aligator-custom-post-types' ),
		'edit_item' => _x( 'Edit Slider','admin_labels', 'aligator-custom-post-types' ),
		'update_item' => _x( 'Update Slider','admin_labels', 'aligator-custom-post-types' ),
		'add_new_item' => _x( 'Add New Slider','admin_labels', 'aligator-custom-post-types' ),
		'new_item_name' => _x( 'New Slider Name','admin_labels', 'aligator-custom-post-types' ),
		'separate_items_with_commas' => _x( 'Separate Sliders with commas','admin_labels', 'aligator-custom-post-types' ),
		'add_or_remove_items' => _x( 'Add or remove Sliders','admin_labels', 'aligator-custom-post-types' ),
		'choose_from_most_used' => _x( 'Choose from the most used Sliders','admin_labels', 'aligator-custom-post-types' ),
		'menu_name' => _x( 'Sliders','admin_labels', 'aligator-custom-post-types' ),
    );
	
    $taxonomy_slider_args = array(
		'labels' => $taxonomy_slider_labels,
		'public' => true,
		'show_in_nav_menus' => true,
		'show_ui' => true,
		'show_tagcloud' => true,
		'hierarchical' => true,
		'rewrite' => true,
		'query_var' => true
    );
	
    register_taxonomy( 'slider', array( 'slide' ), $taxonomy_slider_args );
	
}

//add_action( 'init', 'slide_post_type' );

// Allow thumbnails to be used on slide post type
//add_theme_support( 'post-thumbnails', array( 'slide' ) );
 
/**
 * Add Columns to slide Edit Screen
 * http://wptheming.com/2010/07/column-edit-pages/
 */
 
function slide_post_type_edit_columns($slide_columns){
	$slide_columns = array(
		"cb" => "<input type=\"checkbox\" />",
		"title" => _x('Title', 'column name','aligator-custom-post-types'),
		"thumbnail" => __('Thumbnail', 'aligator-custom-post-types'),
		"slide_category" => __('Slider', 'aligator-custom-post-types'),
		//"slide_tag" => __('Tags', 'aligator-custom-post-types'),
		"author" => __('Author', 'aligator-custom-post-types'),
		"comments" => __('Comments', 'aligator-custom-post-types'),
		"date" => __('Date', 'aligator-custom-post-types'),
	);
	$slide_columns['comments'] = '<div class="vers"><img alt="Comments" src="' . esc_url( admin_url( 'images/comment-grey-bubble.png' ) ) . '" /></div>';
	return $slide_columns;
}

add_filter( 'manage_edit-slide_columns', 'slide_post_type_edit_columns' );
 
function slide_post_type_columns_display($slide_columns, $post_id){

	switch ( $slide_columns )
	
	{
		// Code from: http://wpengineer.com/display-post-thumbnail-post-page-overview
		/* 
		case "thumbnail":
		$width = (int) 35;
		$height = (int) 35;
		$thumbnail_id = get_post_meta( $post_id, '_thumbnail_id', true );
		
		// Display the featured image in the column view if possible
		if ($thumbnail_id) {
			$thumb = wp_get_attachment_image( $thumbnail_id, array($width, $height), true );
		}
		if ( isset($thumb) ) {
			echo $thumb;
		} else {
			echo __('None', 'aligator-custom-post-types');
		}
		break;	
		 */
		// Display the slide tags in the column view
		case "slide_category":
		
		if ( $category_list = get_the_term_list( $post_id, 'slider', '', ', ', '' ) ) {
			echo $category_list;
		} else {
			echo __('None', 'aligator-custom-post-types');
		}
		break;	
		
		/* // Display the slide tags in the column view
		case "slide_tag":
		
		if ( $tag_list = get_the_term_list( $post_id, 'slide_tag', '', ', ', '' ) ) {
			echo $tag_list;
		} else {
			echo __('None', 'aligator-custom-post-types');
		}
		break;	 */		
	}
}

add_action( 'manage_posts_custom_column',  'slide_post_type_columns_display', 10, 2 );

/**
 * Add slide count to "Right Now" Dashboard Widget
 */

function add_slide_counts() {
        if ( ! post_type_exists( 'slide' ) ) {
             return;
        }

        $num_posts = wp_count_posts( 'slide' );
        $num = number_format_i18n( $num_posts->publish );
        $text = _n( 'slide Item', 'slide Items', intval($num_posts->publish) );
        if ( current_user_can( 'edit_posts' ) ) {
            $num = "<a href='edit.php?post_type=slide'>$num</a>";
            $text = "<a href='edit.php?post_type=slide'>$text</a>";
        }
        echo '<td class="first b b-slide">' . $num . '</td>';
        echo '<td class="t slide">' . $text . '</td>';
        echo '</tr>';

        if ($num_posts->pending > 0) {
            $num = number_format_i18n( $num_posts->pending );
            $text = _n( 'slide Item Pending', 'slide Items Pending', intval($num_posts->pending) );
            if ( current_user_can( 'edit_posts' ) ) {
                $num = "<a href='edit.php?post_status=pending&post_type=slide'>$num</a>";
                $text = "<a href='edit.php?post_status=pending&post_type=slide'>$text</a>";
            }
            echo '<td class="first b b-slide">' . $num . '</td>';
            echo '<td class="t slide">' . $text . '</td>';

            echo '</tr>';
        }
}

add_action( 'right_now_content_table_end', 'add_slide_counts' );

/**
 * Add contextual help menu
 */
 
function slide_post_type_add_help_text( $contextual_help, $screen_id, $screen ) { 
	if ( 'slide' == $screen->id ) {
		$contextual_help =
		'<p>' . __('The title field and the big Post Editing Area are fixed in place, but you can reposition all the other boxes using drag and drop, and can minimize or expand them by clicking the title bar of each box. Use the Screen Options tab to unhide more boxes (Excerpt, Send Trackbacks, Custom Fields, Discussion, Slug, Author) or to choose a 1- or 2-column layout for this screen.', 'aligator-custom-post-types') . '</p>' .
		'<p>' . __('<strong>Title</strong> - Enter a title for your post. After you enter a title, you&#8217;ll see the permalink below, which you can edit.', 'aligator-custom-post-types') . '</p>' .
		'<p>' . __('<strong>Post editor</strong> - Enter the text for your post. There are two modes of editing: Visual and HTML. Choose the mode by clicking on the appropriate tab. Visual mode gives you a WYSIWYG editor. Click the last icon in the row to get a second row of controls. The HTML mode allows you to enter raw HTML along with your post text. You can insert media files by clicking the icons above the post editor and following the directions. You can go the distraction-free writing screen, new in 3.2, via the Fullscreen icon in Visual mode (second to last in the top row) or the Fullscreen button in HTML mode (last in the row). Once there, you can make buttons visible by hovering over the top area. Exit Fullscreen back to the regular post editor.', 'aligator-custom-post-types') . '</p>' .
		'<p>' . __('<strong>Publish</strong> - You can set the terms of publishing your post in the Publish box. For Status, Visibility, and Publish (immediately), click on the Edit link to reveal more options. Visibility includes options for password-protecting a post or making it stay at the top of your blog indefinitely (sticky). Publish (immediately) allows you to set a future or past date and time, so you can schedule a post to be published in the future or backdate a post.', 'aligator-custom-post-types') . '</p>' .
		( ( current_theme_supports( 'post-formats' ) && post_type_supports( 'post', 'post-formats' ) ) ? '<p>' . __( '<strong>Post Format</strong> - This designates how your theme will display a specific post. For example, you could have a <em>standard</em> blog post with a title and paragraphs, or a short <em>aside</em> that omits the title and contains a short text blurb. Please refer to the Codex for <a href="http://codex.wordpress.org/Post_Formats#Supported_Formats">descriptions of each post format</a>. Your theme could enable all or some of 10 possible formats.' ) . '</p>' : '' ) .
		'<p>' . __('<strong>Featured Image</strong> - This allows you to associate an image with your post without inserting it. This is usually useful only if your theme makes use of the featured image as a post thumbnail on the home page, a custom header, etc.', 'aligator-custom-post-types') . '</p>' .
		'<p>' . __('<strong>Send Trackbacks</strong> - Trackbacks are a way to notify legacy blog systems that you&#8217;ve linked to them. Enter the URL(s) you want to send trackbacks. If you link to other WordPress sites they&#8217;ll be notified automatically using pingbacks, and this field is unnecessary.', 'aligator-custom-post-types') . '</p>' .
		'<p>' . __('<strong>Discussion</strong> - You can turn comments and pings on or off, and if there are comments on the post, you can see them here and moderate them.', 'aligator-custom-post-types') . '</p>' .
		'<p><strong>' . __('For more information:', 'aligator-custom-post-types') . '</strong></p>' .
		'<p>' . __('<a href="http://codex.wordpress.org/Posts_Add_New_Screen" target="_blank">Documentation on Writing and Editing Posts</a>', 'aligator-custom-post-types') . '</p>' .
		'<p>' . __('<a href="http://wordpress.org/support/" target="_blank">Support Forums</a>', 'aligator-custom-post-types') . '</p>';
  } elseif ( 'edit-slide' == $screen->id ) {
    $contextual_help = 
	    '<p>' . __('You can customize the display of this screen in a number of ways:', 'aligator-custom-post-types') . '</p>' .
		'<ul>' .
		'<li>' . __('You can hide/display columns based on your needs and decide how many posts to list per screen using the Screen Options tab.', 'aligator-custom-post-types') . '</li>' .
		'<li>' . __('You can filter the list of posts by post status using the text links in the upper left to show All, Published, Draft, or Trashed posts. The default view is to show all posts.', 'aligator-custom-post-types') . '</li>' .
		'<li>' . __('You can view posts in a simple title list or with an excerpt. Choose the view you prefer by clicking on the icons at the top of the list on the right.', 'aligator-custom-post-types') . '</li>' .
		'<li>' . __('You can refine the list to show only posts in a specific category or from a specific month by using the dropdown menus above the posts list. Click the Filter button after making your selection. You also can refine the list by clicking on the post author, category or tag in the posts list.', 'aligator-custom-post-types') . '</li>' .
		'</ul>' .
		'<p>' . __('Hovering over a row in the posts list will display action links that allow you to manage your post. You can perform the following actions:', 'aligator-custom-post-types') . '</p>' .
		'<ul>' .
		'<li>' . __('Edit takes you to the editing screen for that post. You can also reach that screen by clicking on the post title.', 'aligator-custom-post-types') . '</li>' .
		'<li>' . __('Quick Edit provides inline access to the metadata of your post, allowing you to update post details without leaving this screen.', 'aligator-custom-post-types') . '</li>' .
		'<li>' . __('Trash removes your post from this list and places it in the trash, from which you can permanently delete it.', 'aligator-custom-post-types') . '</li>' .
		'<li>' . __('Preview will show you what your draft post will look like if you publish it. View will take you to your live site to view the post. Which link is available depends on your post&#8217;s status.', 'aligator-custom-post-types') . '</li>' .
		'</ul>' .
		'<p>' . __('You can also edit multiple posts at once. Select the posts you want to edit using the checkboxes, select Edit from the Bulk Actions menu and click Apply. You will be able to change the metadata (categories, author, etc.) for all selected posts at once. To remove a post from the grouping, just click the x next to its name in the Bulk Edit area that appears.', 'aligator-custom-post-types') . '</p>' .
		'<p><strong>' . __('For more information:', 'aligator-custom-post-types') . '</strong></p>' .
		'<p>' . __('<a href="http://codex.wordpress.org/Posts_Screen" target="_blank">Documentation on Managing Posts</a>', 'aligator-custom-post-types') . '</p>' .
		'<p>' . __('<a href="http://wordpress.org/support/" target="_blank">Support Forums</a>', 'aligator-custom-post-types') . '</p>';

  }
  return $contextual_help;
}

add_action( 'contextual_help', 'slide_post_type_add_help_text', 10, 3 );

/**
 * Displays the custom post type icon in the dashboard
 */

function slide_post_type_slide_icons() {
    
	global $wp_version;
	
	if( version_compare( $wp_version, '3.8', '>=') ) {
	?>
		<style type="text/css" media="screen">
		#adminmenu .menu-icon-slide div.wp-menu-image:before {
			content: "\f181";
		}
		</style>
	
	<?php }else{ ?>
	
		<style type="text/css" media="screen">
		#menu-posts-slide .wp-menu-image {
			background: url(<?php echo plugins_url( '/images/slide-icon.png', __FILE__ ) ?>) no-repeat 6px 6px !important;
		}
		#menu-posts-slide:hover .wp-menu-image, #menu-posts-slide.wp-has-current-submenu .wp-menu-image {
			background-position:6px -16px !important;
		}
		#icon-edit.icon32-posts-slide {background: url(<?php echo plugins_url( '/images/slide-32x32.png', __FILE__ ) ?>) no-repeat;}
		</style>
		
	<?php }; ?>
    
<?php }

add_action( 'admin_head', 'slide_post_type_slide_icons' );
